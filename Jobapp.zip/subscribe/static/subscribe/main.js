function task() {
        alert("Thanks for clicking.");
      }